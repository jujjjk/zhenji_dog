import json
import hashlib
from pathlib import Path

import numpy as np
import onnx
from onnx.reference import ReferenceEvaluator

from mydog_policy.clearance_robust_contract import (
    MODEL_SHA256,
    clearance_calf_amplitude,
    clearance_gait_offset,
    validate_metadata,
)


def test_manifest_contract():
    path = (
        Path(__file__).resolve().parents[1]
        / "resource"
        / "fanfan_clearance_robust_5730.json"
    )
    validate_metadata(json.loads(path.read_text(encoding="utf-8")))


def test_onnx_metadata_matches_sidecar_manifest():
    resource = Path(__file__).resolve().parents[1] / "resource"
    model = onnx.load(
        str(resource / "fanfan_clearance_robust_5730.onnx"),
        load_external_data=False,
    )
    metadata = {item.key: item.value for item in model.metadata_props}
    embedded = json.loads(metadata["fanfan_deployment_config"])
    sidecar = json.loads(
        (resource / "fanfan_clearance_robust_5730.json").read_text(
            encoding="utf-8"
        )
    )
    assert embedded == sidecar
    validate_metadata(embedded)
    onnx.checker.check_model(model)


def test_dynamic_clearance_amplitudes():
    gravity = np.array([0.0, 0.0, -1.0], dtype=np.float32)
    amp, info = clearance_calf_amplitude([0.35, 0.0, 0.0], 10.0, gravity)
    assert np.isclose(amp, -0.30)
    assert not info["motion"]

    amp, info = clearance_calf_amplitude([0.0, 0.07, 0.0], 10.0, gravity)
    assert np.isclose(amp, -0.42)
    assert info["lateral_motion"]

    amp, info = clearance_calf_amplitude([0.0, 0.0, 0.70], 10.0, gravity)
    assert np.isclose(amp, -0.35)
    assert info["yaw_motion"]

    amp, info = clearance_calf_amplitude([0.35, 0.0, 0.0], 0.0, gravity)
    assert np.isclose(amp, -0.33)
    assert info["transition"]

    tilted = np.array([0.10, 0.0, -0.995], dtype=np.float32)
    amp, info = clearance_calf_amplitude([0.0, 0.07, 0.0], 10.0, tilted)
    assert np.isclose(amp, -0.42 * 1.14, atol=1.0e-6)
    assert np.isclose(info["tilt_boost"], 1.14, atol=1.0e-6)


def test_exact_5730_model_sha256():
    path = (
        Path(__file__).resolve().parents[1]
        / "resource"
        / "fanfan_clearance_robust_5730.onnx"
    )
    assert hashlib.sha256(path.read_bytes()).hexdigest() == MODEL_SHA256


def test_reference_gait_matches_mujoco_mid_swing():
    stance_ratio = 0.62
    phase = stance_ratio + 0.5 * (1.0 - stance_ratio)
    command = np.array([0.0, 0.07, 0.0], dtype=np.float32)
    gravity = np.array([0.0, 0.0, -1.0], dtype=np.float32)

    offset, info = clearance_gait_offset(
        phase,
        command,
        transition_age_s=10.0,
        projected_gravity=gravity,
    )
    gate = 1.0 - np.exp(-(0.07 ** 2) / 0.0004)
    expected = -0.42 * gate

    # At this base phase FL/RR are at swing apex; FR/RL are in stance.
    np.testing.assert_allclose(offset[[2, 11]], expected, atol=1.0e-7)
    np.testing.assert_allclose(offset[[5, 8]], 0.0, atol=1.0e-7)
    np.testing.assert_allclose(offset[[0, 1, 3, 4, 6, 7, 9, 10]], 0.0)
    assert np.isclose(info["gait_gate"], gate)
    assert np.isclose(info["calf_amplitude"], -0.42)


def test_zero_command_gates_reference_gait_only():
    offset, info = clearance_gait_offset(
        0.81,
        [0.0, 0.0, 0.0],
        transition_age_s=10.0,
        projected_gravity=[0.0, 0.0, -1.0],
    )
    np.testing.assert_array_equal(offset, np.zeros(12, dtype=np.float32))
    assert info["gait_gate"] == 0.0


def test_onnx_left_right_mirror_error_is_zero():
    resource = Path(__file__).resolve().parents[1] / "resource"
    model = onnx.load(
        str(resource / "fanfan_clearance_robust_5730.onnx"),
        load_external_data=False,
    )
    evaluator = ReferenceEvaluator(model)
    rng = np.random.default_rng(5730)
    observations = rng.normal(0.0, 0.2, (4, 52)).astype(np.float32)
    observations[:, 8] = -1.0
    observations[:, 49] = 1.0

    mirrored = observations.copy()
    mirrored[:, [1, 7, 10, 3, 5, 11]] *= -1.0
    leg_mirror = np.array([1, 0, 3, 2])
    joint_sign = np.array([-1.0, 1.0, 1.0], dtype=np.float32)
    for start in (12, 24, 36):
        block = observations[:, start:start + 12].reshape(-1, 4, 3)
        mirrored[:, start:start + 12] = (
            block[:, leg_mirror, :] * joint_sign
        ).reshape(-1, 12)
    mirrored[:, 48:50] *= -1.0
    mirrored[:, 50] *= -1.0

    actions = evaluator.run(None, {"observations": observations})[0]
    mirrored_actions = evaluator.run(None, {"observations": mirrored})[0]
    mirrored_back = (
        mirrored_actions.reshape(-1, 4, 3)[:, leg_mirror, :] * joint_sign
    ).reshape(-1, 12)
    np.testing.assert_array_equal(actions, mirrored_back)


def test_launch_is_exact_13_nm_simulation_profile():
    launch = (
        Path(__file__).resolve().parents[1]
        / "launch"
        / "sim2real_clearance_robust_5730.launch.py"
    ).read_text(encoding="utf-8")
    assert '"policy_hz": 50.0' in launch
    assert '"zero_cmd_inhibits_policy": False' in launch
    assert '"enable_zero_cmd_stand_protection": False' in launch
    assert '"motor_torque_limit_nm": 13.0' in launch
    assert '"torque_safety_budget_nm": 13.0' in launch
    assert '"motion_torque_ff_limit_nm": 13.0' in launch
    assert '"enable_rear_torque_boost": False' in launch
    assert '"deployment_gait_phase_period_scale": 1.0' in launch
    assert '"gait_phase_lead_sec": 0.0' in launch
    assert '"enable_target_smoothing": False' in launch
    assert '"enable_velocity_ff": False' in launch
    assert 'default_value=MODEL_SHA256' in launch
    assert "FindPackageShare(\"mydog_policy\")" in launch
